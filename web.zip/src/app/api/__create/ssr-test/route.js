﻿// Auto-generated placeholder to avoid SSR import errors
export async function GET() {
  return new Response(JSON.stringify({ ok: true, file: 'src\app\api\__create\ssr-test\route.js' }), {
    status: 200,
    headers: { 'content-type': 'application/json' }
  });
}
