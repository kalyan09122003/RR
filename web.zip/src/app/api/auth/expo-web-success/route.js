﻿// Auto-generated placeholder to avoid SSR import errors
export async function GET() {
  return new Response(JSON.stringify({ ok: true, file: 'src\app\api\auth\expo-web-success\route.js' }), {
    status: 200,
    headers: { 'content-type': 'application/json' }
  });
}
